import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class AB3 extends Roboter
{

    /*#
     * Aufgabe 1: Feuer loeschen
     */
    public void loesche() {
        einsVor();
        aufnehmen();
        vorBisFeuer();
        Feuerbrunstloeschen();
    }

    /*#
     * Aufgaben 3 & 4: Vor bis zum Feuer (wo auch immer das ist)
     */
    public void vorBisFeuer() 
    {
        while(!istVorne("Feuer")) {
            einsVor();
        }
    }

    /*#
     * Aufgabe 5: Feuersbrunst loeschen
     */
    public void Feuerbrunstloeschen()
    {
    while(!istVorne("Wand")) {
        benutze("Feuerloescher");
        einsVor();
    }
}
/*#
     * Aufgabe 6: Teste Reichweite eines Feuerloeschers
     */
    public void reichweitetesten() {
        einsVor();
        dreheLinks();
        einsVor();
        aufnehmen();
        dreheLinks();
        dreheLinks();
        einsVor();
        einsVor();
        dreheLinks();
        if(getAnzahl("Feuerloescher")>=1) {
        benutze("Feuerloescher");
        vorBisFeuer();
    }
        if(getAnzahl("Feuerloescher")>=1) {
        benutze("Feuerloescher");
        vorBisFeuer();
    }
    if(getAnzahl("Feuerloescher")>=1) {
        benutze("Feuerloescher");
        vorBisFeuer();
    }
    if(getAnzahl("Feuerloescher")>=1) {
        benutze("Feuerloescher");
        vorBisFeuer();
    }
    if(getAnzahl("Feuerloescher")>=1) {
        benutze("Feuerloescher");
        vorBisFeuer();
    }
    if(getAnzahl("Feuerloescher")>=1) {
        benutze("Feuerloescher");
        vorBisFeuer();
    }
}
    /*#
     * Aufgabe 7: Feuerloescher einsammeln
     */
    public void sammleLoescher() 
    {
        while(!istVorne("Wand")) {
        einsVor();
        dreheLinks();
        einsVor();
        aufnehmen();
        dreheLinks();
        dreheLinks();
        einsVor();
        dreheLinks();
        einsVor();
    }  
}

    /*#
     * Hilfsmethode fuer Aufgabe 8
     */
    public void laufeBisWand() {
        while(istVorneFrei()) {
            einsVor();
        }
    }

    /*#
     * Aufgabe 8: Homerun
     */
    public void laufeBisSackgasse() {
        while(istVorneFrei()) {
        laufeBisWand();
        dreheLinks();
    }
    }

    /*#
     * Einsatz 3: Bitte den Namen nicht aendern!
     */
    public void einsatz3() {
        sammleLoescher();
        dreheRechts(); 
        einsVor();
        einsVor();
        dreheRechts();
        vorBisFeuer();
        Feuerbrunstloeschen();
        dreheLinks();
        benutze("Feuerloescher");
        einsVor();
        dreheLinks();
        while(istVorne("Feuer")) {
            benutze("Feuerloescher");
            einsVor();
        }
        laufeBisWand();
        dreheRechts();
        einsVor();
        dreheRechts();
        vorBisFeuer();
        Feuerbrunstloeschen();
        dreheLinks();
        benutze("Feuerloescher");
        einsVor();
        dreheLinks();
        while(istVorne("Feuer")) {
            benutze("Feuerloescher");
            einsVor();
        }
        laufeBisWand();
        dreheRechts();
        einsVor();
        dreheRechts();
        vorBisFeuer();
        Feuerbrunstloeschen();
        dreheLinks();
        benutze("Feuerloescher");
        einsVor();
        dreheLinks();
        while(istVorne("Feuer")) {
            benutze("Feuerloescher");
            einsVor();
        }
        laufeBisWand();
        
    }
}

    