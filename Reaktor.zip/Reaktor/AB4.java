import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class AB4 extends Roboter
{
    /*#
     * Aufgabe 1: Spur invertieren
     */
    /** 
     * Der Roboter tauscht aus. Wo eine Schraube liegt, hebt er sie auf.
     * Wo keine liegt, legt er eine ab, wenn er noch Schrauben 
     * in seinem Vorrat hat.
     */
    public void tausche() {
        if (istAufGegenstand("Schraube")) { 
            aufnehmen();
        } 
        else {
            ablegen("Schraube");
        }
    }

    /** 
     * Der Roboter macht mehrere Dinge. Beschreibe in diesem Kommentar:
     * 
     */
    public void tauscheUndVor() {
        tausche();
        if (istVorneFrei()) { 
            einsVor();
        }
        // else ist nicht noetig, weil in dem Fall nichts gemacht wird!                 
    }

    /*#
     * Aufgabe 2: Tausche die Schraubenreihe bis zur Wand
     */
    public void tauscheBisWand() {
        while(!istVorne("Wand")){
            tauscheUndVor();
        }
        tausche();
    }

    /*#
     * Aufgabe 3: Fleckenfrei
     */
    public void umgeheOelfleck() {
        while(!istVorne("Wand")){
        if(!istVorne("Oelfleck")){
            einsVor();
        }
        else{
            dreheLinks();
            einsVor();
            dreheRechts();
            einsVor();
            einsVor();
            dreheRechts();
            einsVor();
            dreheLinks();
        }
    }
    }

    /*#
     * Aufgabe 4: Schluessel aufheben
     */
    public void sammleSchluessel(){
        if(istAufGegenstand("Schluessel")){
            aufnehmen();
        }
    }

    /*#
     * Aufgabe 5: Sesam oeffne dich
     */
    public void oeffneTuer(){
        sammleSchluessel();
        einsVor();
        einsVor();
        einsVor();
        dreheLinks();
        if(istVorne("Schloss")){
            benutze("Schluessel");
        }
        else{
            benutze("Schalter");
        }
        dreheRechts();
        einsVor();
        einsVor();
    }
   

    /*#
     * Hilfsmethode fuer Aufgabe 9
     */
    public void laufeBisWand() {
        while(istVorneFrei()) {
            einsVor();
        }
    }

    /*#
     * Aufgabe 9: Labyrinth
     */
    public void labyrinth(){
       while(!(istWandVorne() && istWandLinks() && istWandRechts())){
       laufeBisWand();
       if(!istWandLinks()){
           dreheLinks();
        }
        else{
            if(!istWandRechts()){
                dreheRechts();
                }
            }
       }
    }

    /*#
     * Einsatz 4: Bitte den Namen nicht aendern!
     */
    public void einsatz4() {
      labyrinth();
      dreheLinks();
      if(istVorne("Schloss")){
            benutze("Schluessel");
      }
      else{
            benutze("Schalter");
      }
      dreheRechts();
      labyrinth();
      dreheLinks();
      if(istVorne("Schloss")){
            benutze("Schluessel");
      }
      else{
            benutze("Schalter");
      }
      dreheRechts();
      labyrinth();
      dreheLinks();
      if(istVorne("Schloss")){
            benutze("Schluessel");
      }
      else{
            benutze("Schalter");
      }
      dreheRechts();
      einsVor();
      einsVor();
      dreheLinks();
      einsVor();
      einsVor();
      while(!istWandVorne()){
          dreheLinks();
          if(istVorne("Schalter")){
          benutze("Schalter");
        }
          dreheRechts();
          einsVor();
        }
    }
    
}
